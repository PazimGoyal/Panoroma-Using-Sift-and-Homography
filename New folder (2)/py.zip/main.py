print('Project INSE 6180 by Pazim Goyal :Naive Bayes')

#pandas csv reading library
import pandas
from pandas import DataFrame
import matplotlib.pyplot as plt

#testing and training data files 
file_name="datafile.csv"
file_name2="datafile3.csv"
#------------------------------preprocessing-------------------------
#testing data
print("\nLoading Review Data from CSV file.......")
abc=pandas.read_csv(file_name,names=['rate','txt'])
print("Data Loaded")

#stop words removal
print("\nLoading Stop words ")
files = open('english.txt', 'r') 
setz= files.read()
print("Stop Words Loaded")
review=list()
reviewx=list()
print("Removing Stop words From Review DataSet.....")
for i in abc.txt:
 review.append([w for w in  i.lower().split(" ") if w not in setz]) #taking a review and pazim  splitting it to words and removing all the stop words
print("Stop words Removed \n\nCounting total positive and Negative Classes")




#for every in review:
        






df=DataFrame({'text':review,'gb':abc.rate.values})




#count +ve and -ve reviews
positive=0
negative=0
for i in abc.rate:
 if i==1:
     positive=positive+1
 else :
     negative=negative+1
total=positive+negative
pofp=positive/total #Priors of positive
pofn=negative/total #priors of negative
print("Total Positive Reviews : {}\nTotal Negative Reviews : {}\nP(positive) : {}\nP(negative) {}: ".format(positive,negative,pofp,pofn))

#--------------training of algo----------------------------------------------
temp2=dict()
temp = dict()
print("Counting Vocab")
 
for row_index,row in df.iterrows():
    tem=row['gb']
    if tem ==1: 
       for i in row['text']:
         if i not in temp:
            temp[i]=1
         else:   
            temp[i]=temp[i] + 1
            
            
    elif tem==0:
       for i in row['text']:
         if i not in temp2:
            temp2[i]=1
         else:   
            temp2[i]=temp2[i] + 1

print("Vocab Size of positive words {} ".format(len(temp)))
print("Vocab Size of negative words {} ".format(len(temp2)))
vocab=list()
vocab=temp.copy()
vocab.update(temp2)
print("Vocab Size : {} ".format(len(vocab)))

ppos=dict()
pneg=dict()
summ=0
sumn=0
for i in temp:
 summ=summ+temp[i]
for i in temp2:
 sumn=sumn+temp2[i]
print("\nTotal Words in Positive reviews : {}\nTotal Words in Negative reviews : {}".format(summ,sumn))

#-----------------------------Testing-------------------------------------------------
abcd=pandas.read_csv(file_name2,names=['txt','real'])
review2=list()
print("\nRemoving Stop words From Testing DataSet.....")
for i in abcd.txt:
 review2.append([w for w in  i.lower().split(" ") if w not in setz]) #taking a review and pazim  splitting it to words and removing all the stop words
lastlist=list()

for each in review2:
    ptemp=pofp
    p2temp=pofn
    for i in each:
      ptemp=ptemp * (temp.get(i,0)+1)/(summ+len(vocab))
    for i in each:
      p2temp=p2temp * (temp2.get(i,0)+1)/(sumn+len(vocab))
    if ptemp> p2temp:
      lastlist.append(1)
    else:
      lastlist.append(0)

print(len(lastlist))      

dfpos=DataFrame({'real':abcd.real.values,'count':lastlist,'rev':abcd.txt})
dfpos.to_csv('predictions2.csv')

true=0
false=0
for row_index,row in dfpos.iterrows():
    if row['real'] == row['count']:
        true =true+1
    else:
        false=false+1


labels = 'accuracy', 'error'
sizes = [true,false]
colors = ['gold', 'lightcoral']
explode = (0, 0.1,)  # explode 1st slice
 
# Plot
plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True, startangle=140)
 
plt.axis('equal')
plt.show()

 
print("Done Tata")

