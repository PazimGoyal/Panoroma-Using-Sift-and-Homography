print('Project INSE 6180 by Pazim Goyal :KNN')

#pandas csv reading library
import pandas
from pandas import DataFrame
from math import log
#testing and training data files 
file_name="datafile.csv"
file_name2="datafile3.csv"
#------------------------------preprocessing-------------------------
#testing data
print("\nLoading Review Data from CSV file.......")
abc=pandas.read_csv(file_name,names=['rate','txt'])
print("Data Loaded")

#stop words removal
print("\nLoading Stop words ")
files = open('english.txt', 'r') 
setz= files.read()
print("Stop Words Loaded")
review=list()
print("Removing Stop words From Review DataSet.....")
for i in abc.txt:
 review.append([w for w in  i.lower().split(" ") if w not in setz]) #taking a review and pazim  splitting it to words and removing all the stop words
print("Stop words Removed \n\nCounting total positive and Negative Classes")







df=DataFrame({'text':review,'gb':abc.rate.values})
temp = dict()
print("Counting Vocab")
 
for row_index,row in df.iterrows():
    for i in row['text']:
        if i not in temp:
            temp[i]=1
        else:   
            temp[i]=temp[i] + 1
print(len(temp))
unqwords=temp.keys()

#---------------------------------testing-----------------------------

line=" This is a bad product. It worked well for 1 month and then just stopped working. Waste of money so dont buy., "
abcd=pandas.read_csv(file_name2,names=['txt','real'])
review2=list()
review3=[]
answer=[]
print("\nRemoving Stop words From Testing DataSet.....")
c=0
length=len(review)

for i in abcd.txt.head():    
        review2.append([w for w in  i.lower().split(" ") if w not in setz]) #taking a review and pazim  splitting it to words and removing all the stop words
for i in review2:
    review3.append([w for w in  i if w  in unqwords]) 


for testing in review3:
        final=[]
        for row_index,row in df.iterrows():
            words=[x for x in row['text'] if x in testing]
            kscore=0.0
            for each in words:
                kscore=kscore+log(length/temp[each])
            final.append((kscore,row['gb']))
        final.sort(reverse=True)

        poss=[]
        negs=[]
        for i in final[:7]:
           if i[1] == 1:
             poss.append(i[1])
           else :
             negs.append(i[1]) 

        if len(poss)>len(negs):
            answer.append(1)
        else:
            answer.append(0)
        print(answer)    

    

